# Minecraft-WebSite DarkOrange

Simple website made for Minecraft servers!

The project was made only with HTML, CSS and JavaScript, without using frameworks.

The project is simple, depending on the result obtained in the community, I can continue developing it and fixing problems.

Characteristics:

 1. Five pages to customize and adapt to the server.
 2. Bar with online or offline server status with player numbers.
 3. Easy configuration file with the main adjustments you should make to the website. (found in js/core.js folder)
 4. Auto responsive

Online demo: https://tiagox42.github.io/Minecraft-WebSite-1-DarkOrange/

Some images:

![enter image description here](https://i.imgur.com/CAvlEAL.png)
![enter image description here](https://i.imgur.com/e7kQxCD.png)
![enter image description here](https://i.imgur.com/4Jjkhfv.png)



***It is not allowed to sell or post the files elsewhere, if you use the website on your server please give credit to this github, I intend to become a developer and spreading my work would help me a lot.***
