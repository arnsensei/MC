function openContent1() {
    var show1 = document.getElementById('content1');
    var but1 = document.getElementById('button1');
    if ( !show1.style.display || show1.style.display == 'none') {
        show1.style.display = 'block';
        but1.value = '-';
    } else {
            show1.style.display = 'none'
            but1.value = '+';
        }
}

function openContent2() {
    var show1 = document.getElementById('content2');
    var but1 = document.getElementById('button2');
    if (!show1.style.display || show1.style.display == 'none') {
        show1.style.display = 'block';
        but1.value = '-';
    } else {
            show1.style.display = 'none'
            but1.value = '+';
        }
}

function openContent3() {
    var show1 = document.getElementById('content3');
    var but1 = document.getElementById('button3');
    if (!show1.style.display || show1.style.display == 'none') {
        show1.style.display = 'block';
        but1.value = '-';
    } else {
            show1.style.display = 'none'
            but1.value = '+';
        }
}

function openContent4() {
    var show1 = document.getElementById('content4');
    var but1 = document.getElementById('button4');
    if (!show1.style.display || show1.style.display == 'none') {
        show1.style.display = 'block';
        but1.value = '-';
    } else {
            show1.style.display = 'none'
            but1.value = '+';
        }
}