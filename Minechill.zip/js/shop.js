function Vip1() {
    window.location.href = "https://github.com/Tiagox42/Minecraft-WebSite";
}

function Vip2() {
    window.location.href = "https://github.com/Tiagox42/Minecraft-WebSite";
}

function Vip3() {
    window.location.href = "https://github.com/Tiagox42/Minecraft-WebSite";
}

function Vip4() {
    window.location.href = "https://github.com/Tiagox42/Minecraft-WebSite";
}

function Vip5() {
    window.location.href = "https://github.com/Tiagox42/Minecraft-WebSite";
}

function Vip6() {
    window.location.href = "https://github.com/Tiagox42/Minecraft-WebSite";
}